<?php

App::uses('AppModel','Model');
class Page extends AppModel{
    
}